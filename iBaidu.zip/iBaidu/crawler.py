#!/usr/bin/env python
# -*- coding: utf-8 -*-

from gevent import monkey; monkey.patch_all()
from gevent.pool import Pool as Gpool
import requests
from bs4 import BeautifulSoup
import re
import sys
from time import time

reload(sys)
sys.setdefaultencoding('utf-8')

# 记录条目最佳匹配率
best_match_rate = 0
# 记录匹配条目数
best_match_cnt = 0
# 记录最佳关键词字符串
best_keyword_str = ''
# 记录最佳匹配率下匹配文本的url
best_url_list = []
# 记录最佳匹配率下匹配文本的title
best_title_list = []

def get_soup(data):
	'''
	将BeautifulSoup查询得到的tag对象转换为新的可查询的BeautifualSoup对象。
	也可以用来从XML字符串获得BeautifualSoup对象。
	'''
	if not isinstance(data, basestring): data = str(data)
	return BeautifulSoup(data, 'lxml')

def get_url(url):
	'''
	请求页面数据并进行预处理，提取页面中各条目的url
	'''
	# 请求页面直到成功
	while True:
		try:
			response = requests.get(url)
			break
		except Exception, e:
			pass
	# 预处理页面数据，提取url
	soup = get_soup(response.text)
	soup = soup.find(id='content_left')
	items = soup.find_all(class_='c-container')
	urls = []
	for item in items:
		urls.append(get_soup(item).a['href'])
	return urls

def crawl_url(keyword_str, target_num):
	'''
	根据给定的关键词字符串和目标条目数尝试从百度搜索引擎抓取数据。
	百度搜索引擎无法提供足够多条目时函数返回None，否则返回条目的url及对应网页文本。
	keyword_str：关键词字符串，关键词已空格分割
	target_num：目标条目数
	'''
	# 目标条目数太多
	if target_num > 512:
		target_num = 512
	# 获取数据条目数
	base_url = 'http://www.baidu.com/s?wd=%s&pn=%d'
	response = requests.get(base_url % (keyword_str, 0))
	soup = get_soup(response.text)
	num_div = str(soup.find(attrs={'class': 'nums'}))
	num = re.search(r'(?<=百度为您找到相关结果约).+(?=个)', num_div).group(0)
	num = int(''.join(num.split(',')))
	print '共搜索到%d个条目' % num
	# 数据条目数太少
	if num < target_num:
		return None
	# 生成页码上限
	if target_num % 10 != 0:
		target_num += 10
	pn_limit = target_num/10*10
	# 生成请求队列
	gpool = Gpool(64)
	url_list = [base_url % (keyword_str, p) for p in xrange(0, pn_limit, 10)]
	print '开始抓取条目url...'
	time0 = time()
	url_groups = gpool.map(get_url, url_list)
	cost_time = time() - time0
	url_list = []
	for url_group in url_groups:
		url_list += url_group
	print '抓取%d个条目url，用时%.2f秒' % (len(url_list), cost_time)
	return url_list

def match(kwargs):
	'''
	对给定文本尝试全文匹配。
	'''
	def real_match(text, original_texts):
		text = str(get_soup(text).body)
		for original_text in original_texts:
			# 验证存在性用in快，验证不存在性用find快
			if text.find(original_text) == -1:
			# if original_text not in text:
				return False
		return True
	return real_match(**kwargs)

def check_text(content_list, original_texts):
	'''
	检查各个条目对应文本与原文的匹配情况。
	'''
	gpool = Gpool(512)
	kwargs = [{'text': content['text'], 'original_texts': original_texts} for content in content_list]
	# results = [match(kwarg) for kwarg in kwargs] # 串行方式
	results = gpool.map(match, kwargs) # 并行方式
	# 统计匹配数并标记匹配失败的条目
	cnt = 0
	for i in xrange(len(results)):
		if not results[i]:
			content_list[i]['url'] = None
			continue
		cnt += 1
	return cnt

def get_content(url):
	'''
	抓取条目url对应的网页文本。
	'''
	try:
		response = requests.get(url, timeout=3)
	except Exception, e:
		return None
	# 获取条目的真实url和网页文本
	content = {'url': response.url, 'text': response.content}
	return content

def get_title(text):
	'''
	提取网页文本中的title字段。
	'''
	soup = get_soup(text)
	title_tag = soup.title
	if not title_tag or not title_tag.string:
		return '无标题页面'
	return title_tag.string.strip()

def check_url(url_list, keyword_str):
	'''
	检查搜索到的条目与给定原文的匹配程度。
	'''
	global best_match_rate, best_match_cnt, best_keyword_str, best_url_list, best_title_list
	# 读取原文
	original_texts = []
	f = open('original_texts')
	for line in f:
		original_texts.append(line.strip())
	f.close()
	# 抓取文本
	gpool = Gpool(512)
	print '开始抓取条目文本...'
	time0 = time()
	content_list = gpool.map(get_content, url_list)
	cost_time = time() - time0
	content_list = [content for content in content_list if content] # 过滤访问失败的条目
	content_cnt = len(content_list)
	print '成功抓取%d个条目文本，用时%.2f秒' % (content_cnt, cost_time)
	# 统计全文匹配的文本
	print '开始统计匹配的文本...'
	match_cnt = check_text(content_list, original_texts)
	match_rate = match_cnt/float(content_cnt)
	# match_rate = match_cnt/float(len(url_list))
	print '匹配数：%d，匹配率：%.2f%%' % (match_cnt, match_rate*100)
	# 更新最佳搜索结果相关信息
	if match_rate > best_match_rate:
		best_match_rate = match_rate
		best_match_cnt = match_cnt
		best_keyword_str = keyword_str
		best_url_list = [content['url'] for content in content_list if content['url']]
		best_title_list = [get_title(content['text']) for content in content_list if content['url']]

def crawl(keyword_str, target_num):
	'''
	按照给定的关键词字符串，从百度搜索引擎抓取搜索结果条目对应的url。
	利用给定的原文，匹配这些条目url对应的网页文本，统计匹配数与匹配率。
	'''
	url_list = crawl_url(keyword_str, target_num)
	if url_list:
		check_url(url_list, keyword_str)
	else:
		print '没有足够多的搜索结果'

if __name__ == '__main__':
	'''
	模块独立测试。
	'''
	keyword_str = 'hadoop'
	target_num = 100
	crawl(keyword_str, target_num)