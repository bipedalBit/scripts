#!/usr/bin/env python
# -*- coding: utf-8 -*-

import crawler
import sys
from time import time

keywords = []
words_cnt = 0
used = []
keyword_str_list = []
stack = []

def gen_str(len):
	global keywords, words_cnt, used, keyword_str_list, stack
	if len == words_cnt:
		return
	for i in xrange(words_cnt):
		if not used[i]:
			used[i] = True
			stack.append(keywords[i])
			new_str = ' '.join(sorted(stack))
			if keyword_str_list.count(new_str) == 0:
				keyword_str_list.append(new_str)
			gen_str(len+1)
			stack.pop()
			used[i] = False

def try_search(target_num):
	'''
	根据'keyword'文件中的可选关键词生成不同的关键词组合，
	使用'original_text'文件中的原文进行全文匹配，统计原文的引用情况。
	'''
	global keywords, words_cnt, used, keyword_str_list
	# 读取关键词
	f = open('keywords')
	for line in f:
		keywords.append(line.strip())
	f.close()
	# 生成关键词的所有组合
	words_cnt = len(keywords)
	used = [False]*words_cnt
	gen_str(0)
	print '共生成%d种关键词组合' % len(keyword_str_list)
	# 依次尝试所有关键词组合
	match_rate_list = []
	for keyword_str in keyword_str_list:
		print '尝试组合“%s”：' % keyword_str
		crawler.crawl(keyword_str, target_num)
	# 输出搜索结果
	if crawler.best_match_rate == 0:
		sorry_str = '搜索结果不理想，请更换目标条目数、关键词或原文核心句'
		print sorry_str
		f = open('output', 'w')
		f.write(sorry_str)
		f.close()
	else:
		print '最佳关键词组合为：“%s”，匹配率为%.2f%%' % (crawler.best_keyword_str, crawler.best_match_rate*100)
		item_list = []
		for i in xrange(crawler.best_match_cnt):
			item_list.append(crawler.best_title_list[i] + '\n' + crawler.best_url_list[i])
		output_str = '\n\n'.join(item_list)
		f = open('output', 'w')
		f.write(output_str)
		f.close()

def get_time_cost_str(time_cost):
	'''
	格式化时间开销（time()函数返回值的差），返回时间开销字符串。
	'''
	int_time_cost = int(time_cost)
	time_cost_str = ''
	day_seconds = 3600*24
	if time_cost < 60:
		time_cost_str += str(time_cost) + '秒'
	elif 60 <= time_cost < 3600:
		time_cost_str += str(int_time_cost/60) + '分' + str(time_cost%60) + '秒'
	elif 3600 <= time_cost < day_seconds:
		time_cost_str += str(int_time_cost/3600)  + '小时' + str(int_time_cost/60%60) + '分' + str(time_cost%60) + '秒'
	else:
		time_cost_str += str(int_time_cost/day_seconds) + '天' + str(int_time_cost/3600%24)  + '小时'\
		+ str(int_time_cost/60%60) + '分' + str(time_cost%60) + '秒'
	return time_cost_str

if __name__ == '__main__':
	target_num = raw_input('请输入目标条目数：')
	tmp = sys.stdout
	sys.stdout = open('log', 'w')
	time0 = time()
	try_search(int(target_num))
	cost_time = time() - time0
	print '本次搜索共用时%s' % get_time_cost_str(cost_time)
	sys.stdout.close()
	sys.stdout = tmp